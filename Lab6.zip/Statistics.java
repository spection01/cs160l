import java.time.LocalDateTime;
import java.util.List;

public class Statistics {
    private List<CoffeeOrder> orders;

    public Statistics(List<CoffeeOrder> orders) {}

    public double getTotal(LocalDateTime start, LocalDateTime end) {
        return 0;
    }

    public double getAvgCost() {
        return 0;
    }

    public String[] getPopularOrders(int maxRank) {
        return null;
    }

    public String printStatistics() {
        return "";
    }
}
